# encoding:utf-8

from tkinter import *
from tkinter import ttk


class App(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.geometry('640x420')
        self.resizable(0, 0)
        self.title('串口工具(自用-51单片机)')
        self.div_left = Div_Left()
        self.div_right = Div_Right()


class Div_Left(Frame):
    def __init__(self, master=None):
        Frame.__init__(self)
        self.createWidgets()
        self.pack(side=LEFT, fill='y')

    def createWidgets(self):
        self.Message = Text(self, width=48, height=20, bg='Black', foreground='blue')
        self.Message.grid(row=0, column=0, pady=5, padx=5)
        self.scr_1 = Scrollbar(self, orient=VERTICAL)
        self.scr_1.grid(row=0, column=1, sticky=N + S + W)
        self.scr_1.config(command=self.Message.yview)
        self.Message.config(yscrollcommand=self.scr_1.set)
        self.Send = Text(self, width=48, height=10)
        self.Send.grid(row=1, column=0)
        self.scr_2 = Scrollbar(self, orient=VERTICAL)
        self.scr_2.grid(row=1, column=1, sticky=N + S + W)
        self.scr_2.config(command=self.Send.yview)
        self.Send.config(yscrollcommand=self.scr_2.set)


class Div_Right(Frame):
    def __init__(self, master=None):
        Frame.__init__(self)
        self.createWidgets()
        self.pack(side=LEFT, fill='y', )

    def createWidgets(self):
        # 复选框的值
        self.var_1 = IntVar()
        self.var_2 = IntVar()
        self.var_3 = IntVar()
        self.var_4 = IntVar()
        self.var_6 = IntVar()
        ###################
        self.lobel1 = Label(self, text='串口选择:', padx=10)
        self.lobel1.grid(row=0, column=0, padx=5)
        self.list_1 = ttk.Combobox(self, state='readonly')
        self.list_1.grid(row=0, column=1)
        self.lobel2 = Label(self, text='波特率:', padx=10)
        self.lobel2.grid(row=1, column=0, padx=5, pady=15)
        self.list_2 = ttk.Combobox(self, state='readonly')
        self.list_2.grid(row=1, column=1)
        self.list_2['value'] = ['1382400', '460800', '230400', '115200', '38400', '9600']
        self.list_2.current(5)
        self.lobel3 = Label(self, text='停止位:', padx=10)
        self.lobel3.grid(row=2, column=0, padx=5)
        self.list_3 = ttk.Combobox(self, state='readonly')
        self.list_3.grid(row=2, column=1)
        self.list_3['value'] = ['1', '1.5', '2']
        self.list_3.current(0)
        self.lobel4 = Label(self, text='数据位:', padx=10)
        self.lobel4.grid(row=3, column=0, padx=5, pady=15)
        self.list_4 = ttk.Combobox(self, state='readonly')
        self.list_4.grid(row=3, column=1)
        self.list_4['value'] = ['8', '7', '6', '5']
        self.list_4.current(0)
        self.lobel5 = Label(self, text='奇偶校验位:', padx=10)
        self.lobel5.grid(row=4, column=0, padx=5)
        self.list_5 = ttk.Combobox(self, state='readonly')
        self.list_5.grid(row=4, column=1)
        self.list_5['value'] = ['None', 'Odd', 'Even', 'Mark', 'Space']
        self.list_5.current(0)
        self.lobel6 = Label(self, text='串口操作:', padx=10)
        self.lobel6.grid(row=5, column=0, padx=5, pady=15)
        self.butoon_1 = Button(self, text='串口打开', width=20, bg='green', foreground='red')
        self.butoon_1.grid(row=5, column=1)
        self.rad_1 = Checkbutton(self, text='RTS', variable=self.var_1)
        self.rad_1.grid(row=6, column=0)
        self.butoon_2 = Button(self, text='接受清除', width=20)
        self.butoon_2.grid(row=6, column=1)
        self.rad_2 = Checkbutton(self, text='DTR', variable=self.var_2)
        self.rad_2.grid(row=7, column=0)
        self.rad_3 = Checkbutton(self, text='16位进制接收', variable=self.var_3)
        self.rad_3.grid(row=7, column=1)
        self.button_3 = Button(self, text='发送', height=7, width=10)
        self.button_3.grid(row=8, column=0, rowspan=8)
        self.rad_4 = Checkbutton(self, text='16位进制发送', variable=self.var_4)
        self.rad_4.grid(row=8, column=1)
        self.rad_6 = Checkbutton(self, text='添加行发送', variable=self.var_6)
        self.rad_6.grid(row=10, column=1)