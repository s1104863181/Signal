# encoding:utf-8
import serial
import serial.tools.list_ports
from GUI import *
import re


##读取数据
def tread_RXD():
    global ser
    try:
        if ser != 0:
            Read_2()
        return 0
    except Exception as e:
        print(e)
        return 0


# 读取方式2
def Read_2():
    if ser.in_waiting:
        if app.div_right.var_3.get() == 1:
            data = str(ser.read().hex())
            app.div_left.Message.insert(END, data + ' ')
        else:
            data = str(ser.read().decode('utf-8'))
            app.div_left.Message.insert(END, data)
        app.div_left.Message.see(END)


##读取串口列表
def port(event):
    port_list_1 = list(serial.tools.list_ports.comports())
    port_list_2 = []
    if port_list_1:
        for p in range(0, len(port_list_1)):
            port_list_2.append(str(port_list_1[p])[:4])
        app.div_right.list_1['value'] = port_list_2
    return 0


##打开串口
def start_RXD(event):
    timex = 0
    global ser
    if ser == 0:
        try:
            rxd_ser = serial.Serial(
                app.div_right.list_1.get(),
                app.div_right.list_2.get(),
                timeout=timex,
                stopbits=int(app.div_right.list_3.get()),
                bytesize=int(app.div_right.list_4.get()),
                parity=app.div_right.list_5.get()[0]
            )
            print(rxd_ser)
            if rxd_ser.is_open:
                ser = rxd_ser
                app.div_right.butoon_1['text'] = "串口关闭"
                app.div_right.butoon_1['bg'] = "yellow"
                app.div_right.butoon_1['foreground'] = "black"
                app.div_right.list_1['state'] = 'disabled'
                app.div_right.list_2['state'] = 'disabled'
                app.div_right.list_3['state'] = 'disabled'
                app.div_right.list_4['state'] = 'disabled'
                app.div_right.list_5['state'] = 'disabled'
        except Exception as e:
            ser = 0
            print('异常:--------', e)
        return 0
    ser.close()
    ser = 0
    app.div_right.butoon_1['text'] = "打开串口"
    app.div_right.butoon_1['bg'] = "green"
    app.div_right.butoon_1['foreground'] = "red"
    app.div_right.list_5['state'] = 'readonly'
    app.div_right.list_4['state'] = 'readonly'
    app.div_right.list_3['state'] = 'readonly'
    app.div_right.list_2['state'] = 'readonly'
    app.div_right.list_1['state'] = 'readonly'
    return 0


##接收信息清理
def Message_clear(event):
    app.div_left.Message.delete('1.0', 'end')
    return


def SetRTS(event):
    if ser != 0:
        ser.rtscts = bool(1 - app.div_right.var_1.get())
        print(ser)


def SetDTR(event):
    if ser != 0:
        ser.dsrdtr = bool(1 - app.div_right.var_2.get())


##事件的绑定
def Incident():
    app.div_right.list_1.bind("<Button-1>", port)
    app.div_right.butoon_1.bind('<ButtonRelease-1>', start_RXD)
    app.div_right.butoon_2.bind('<ButtonRelease-1>', Message_clear)
    app.div_right.button_3.bind('<ButtonRelease-1>', Send_Message)
    app.div_right.rad_1.bind('<ButtonRelease-1>', SetRTS)
    app.div_right.rad_2.bind('<ButtonRelease-1>', SetDTR)


def Send_Message(event):
    if ser != 0:  ##串口被打开  16进制发送格式是0x??
        data = app.div_left.Send.get(0.0, END)  ##获取需要发送的数据
        if app.div_right.var_6.get() == 1:  ##是否为行发送
            if app.div_right.var_4.get() == 1:  ##是否是16进制发送
                ser.write(bytes([eval(data)]))  ##16进制发送
            else:
                ser.write(data.encode("utf-8"))
        else:
            if app.div_right.var_4.get() == 1:  ##是否是16进制发送
                ser.write(bytes([eval(data[:-1])]))
            else:
                ser.write(data[:-1].encode("utf-8"))  # 主函数


if __name__ == '__main__':
    ser = 0
    ser_id = []
    app = App()
    Incident()
    while (True):
        tread_RXD()  ##因为不会多线程 感觉好卡 ，所以去找了方法 用这个方法代替了mainloop的方法 然后就单线程了
        app.update_idletasks()  ##这行代码与下行代码合起来与app.mainloop()等同.
        app.update()  ##这行代码与上行代码合起来与app.mainloop()等同.